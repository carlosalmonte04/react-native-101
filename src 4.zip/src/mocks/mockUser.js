export const MOCK_USER = {
  name: "Steve",
  lastName: "Rogers",
  heroName: "Captain America",
  bio:
    "America’s World War II Super-Soldier continues his fight in the present as an Avenger and untiring sentinel of liberty.",
};
