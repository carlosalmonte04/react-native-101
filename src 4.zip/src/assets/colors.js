export const colors={
	primary:'#000000',
	textPrimary: '#FFFFFF',
	red:'red',
	blue:'blue',
	lightgrey:'lightgrey',
	grey:'grey'
}