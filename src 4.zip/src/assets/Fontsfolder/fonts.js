export const fonts={
	defaultFontFamily:'Helvetica'
}