import { createBottomTabNavigator } from "react-navigation-tabs";
import { HomeScreen, ProfileScreen } from "@components";

const appScreens = {
  HomeScreen,
  ProfileScreen,
};

const appNavigatorConfig = {
  initialRouteName: "HomeScreen",
};

export const AppNavigator = createBottomTabNavigator(
  appScreens,
  appNavigatorConfig,
);
