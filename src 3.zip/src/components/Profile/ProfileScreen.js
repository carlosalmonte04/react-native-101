import React from "react";
import { View } from "react-native";

export class ProfileScreen extends React.PureComponent {
  render() {
    return <View>{/* <Image/> */}</View>;
  }
}
