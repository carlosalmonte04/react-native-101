export const images = {
    cap_img: require('./cap.png')
};

// export images;